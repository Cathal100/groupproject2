// JavaScript form validation function
function validateForm() {
    // Get the values from the form
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var message = document.getElementById('message').value;

    // Check if the name field is empty
    if (name.trim() === "") {
        alert("Please enter your name.");
        return false; // Prevent form submission
    }

    // Check if the email field is empty or not in a valid format
    var emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    if (email.trim() === "") {
        alert("Please enter your email.");
        return false; // Prevent form submission
    } else if (!email.match(emailPattern)) {
        alert("Please enter a valid email address.");
        return false; // Prevent form submission
    }

    // Check if the message field is empty
    if (message.trim() === "") {
        alert("Please enter a message.");
        return false; // Prevent form submission
    }

    // If everything is correct, the form will be submitted
    return true;
}
